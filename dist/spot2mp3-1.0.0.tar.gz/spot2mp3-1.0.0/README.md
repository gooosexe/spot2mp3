# desc
convert your favourite spotify playlists and albums to mp3 files!
mp3 files come packaged with correct metadata, including album covers.

# Installation and usage instructions
errr not done yet
