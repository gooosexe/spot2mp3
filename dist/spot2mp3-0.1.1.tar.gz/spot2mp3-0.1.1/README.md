# desc
convert your favourite spotify playlists and albums to mp3 files!

mp3 files come packaged with correct metadata, including album covers.

NOTE: single song download does not work yet. if you want to download a single songs, make a playlist with a single song inside.

# installation 
errr not done yet
